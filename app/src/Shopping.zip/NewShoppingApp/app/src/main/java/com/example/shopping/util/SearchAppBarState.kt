package com.example.shopping.util

enum class SearchAppBarState {
    OPENED,
    CLOSED,
    TRIGGERED
}